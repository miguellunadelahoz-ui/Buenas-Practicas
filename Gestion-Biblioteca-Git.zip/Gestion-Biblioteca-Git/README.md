# Gestion-Biblioteca-Git

Caso practico de control de versiones con Git y GitHub: sistema sencillo de
gestion de una biblioteca universitaria (catalogo de libros, prestamos y
devoluciones).

Trabajo individual - Miguel Luna

## Comandos documentados
Ver comandos.txt para la lista completa de comandos Git usados.
